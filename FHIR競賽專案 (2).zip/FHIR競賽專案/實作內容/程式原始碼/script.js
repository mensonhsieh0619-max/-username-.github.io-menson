/**
 * script.js - AI Health Tracking Platform
 * Logic for SPA navigation, state management, FHIR generation, AI analysis, and Charts.
 */

// --- Initial State & Constants ---
const DEFAULT_DATA = {
    patient: {
        id: "patient-demo-001",
        name: "王小明",
        gender: "male",
        birthDate: "1990-05-20"
    },
    history: [
        { date: "2026-06-01", systolic: 118, diastolic: 78, weight: 72.5, height: 175, hr: 68, steps: 7200, exercise: 40, calories: 300 },
        { date: "2026-06-04", systolic: 122, diastolic: 82, weight: 72.0, height: 175, hr: 72, steps: 9500, exercise: 60, calories: 450 },
        { date: "2026-06-08", systolic: 120, diastolic: 80, weight: 71.8, height: 175, hr: 70, steps: 8100, exercise: 30, calories: 250 },
        { date: "2026-06-12", systolic: 121, diastolic: 79, weight: 71.5, height: 175, hr: 69, steps: 10200, exercise: 45, calories: 350 },
        { date: "2026-06-15", systolic: 119, diastolic: 77, weight: 71.2, height: 175, hr: 67, steps: 8500, exercise: 30, calories: 280 }
    ],
    blockchainLogs: [
        { hash: "0xA7F3...91BC", from: "王小明", to: "Dr. Weaver", data: "全資料", time: "2026-06-15 10:30", status: "Success" },
        { hash: "0x4B21...E088", from: "王小明", to: "Coach Mike", data: "運動紀錄", time: "2026-06-14 15:20", status: "Success" }
    ],
    notifications: [
        { title: "FHIR 資料同步成功", desc: "您的今日量測數據已成功上傳至 HAPI FHIR Server。", time: "10 分鐘前", type: "sync" },
        { title: "運動提醒", desc: "您今天還差 2000 步就達到目標囉！", time: "2 小時前", type: "exercise" },
        { title: "AI 健康分析完成", desc: "根據您的最新數據，AI 已更新了您的健康建議。", time: "1 天前", type: "ai" }
    ],
    role: "user"
};

let state = JSON.parse(localStorage.getItem('health_platform_state')) || DEFAULT_DATA;
let charts = {};

// --- Helper Functions ---
function saveState() {
    localStorage.setItem('health_platform_state', JSON.stringify(state));
}

function calculateBMI(w, h) {
    const heightM = h / 100;
    return (w / (heightM * heightM)).toFixed(1);
}

function getLatestData() {
    return state.history[state.history.length - 1];
}

function formatJSON(obj) {
    return JSON.stringify(obj, null, 2);
}

function generateHash() {
    return "0x" + Math.random().toString(16).substr(2, 4).toUpperCase() + "..." + Math.random().toString(16).substr(2, 4).toUpperCase();
}

// --- FHIR Resource Generator ---
function generateFHIRBundle() {
    const latest = getLatestData();
    const bmi = calculateBMI(latest.weight, latest.height);
    const timestamp = new Date().toISOString();

    const bundle = {
        resourceType: "Bundle",
        type: "collection",
        entry: [
            // Patient
            {
                resource: {
                    resourceType: "Patient",
                    id: state.patient.id,
                    name: [{ text: state.patient.name }],
                    gender: state.patient.gender,
                    birthDate: state.patient.birthDate
                }
            },
            // Blood Pressure
            {
                resource: {
                    resourceType: "Observation",
                    status: "final",
                    category: [{ coding: [{ system: "http://terminology.hl7.org/CodeSystem/observation-category", code: "vital-signs" }] }],
                    code: { coding: [{ system: "http://loinc.org", code: "85354-9", display: "Blood pressure systolic & diastolic" }] },
                    subject: { reference: `Patient/${state.patient.id}` },
                    effectiveDateTime: timestamp,
                    component: [
                        {
                            code: { coding: [{ system: "http://loinc.org", code: "8480-6", display: "Systolic blood pressure" }] },
                            valueQuantity: { value: latest.systolic, unit: "mmHg", system: "http://unitsofmeasure.org", code: "mm[Hg]" }
                        },
                        {
                            code: { coding: [{ system: "http://loinc.org", code: "8462-4", display: "Diastolic blood pressure" }] },
                            valueQuantity: { value: latest.diastolic, unit: "mmHg", system: "http://unitsofmeasure.org", code: "mm[Hg]" }
                        }
                    ]
                }
            },
            // Body Weight
            {
                resource: {
                    resourceType: "Observation",
                    status: "final",
                    code: { coding: [{ system: "http://loinc.org", code: "29463-7", display: "Body Weight" }] },
                    subject: { reference: `Patient/${state.patient.id}` },
                    effectiveDateTime: timestamp,
                    valueQuantity: { value: latest.weight, unit: "kg", system: "http://unitsofmeasure.org", code: "kg" }
                }
            },
            // Heart Rate
            {
                resource: {
                    resourceType: "Observation",
                    status: "final",
                    code: { coding: [{ system: "http://loinc.org", code: "8867-4", display: "Heart rate" }] },
                    subject: { reference: `Patient/${state.patient.id}` },
                    effectiveDateTime: timestamp,
                    valueQuantity: { value: latest.hr, unit: "bpm", system: "http://unitsofmeasure.org", code: "beats/min" }
                }
            },
            // BMI
            {
                resource: {
                    resourceType: "Observation",
                    status: "final",
                    code: { coding: [{ system: "http://loinc.org", code: "39156-5", display: "Body mass index" }] },
                    subject: { reference: `Patient/${state.patient.id}` },
                    effectiveDateTime: timestamp,
                    valueQuantity: { value: parseFloat(bmi), unit: "kg/m2", system: "http://unitsofmeasure.org", code: "kg/m2" }
                }
            }
        ]
    };
    return bundle;
}

// --- AI Engine ---
function runAIAnalysis() {
    const latest = getLatestData();
    const bmi = parseFloat(calculateBMI(latest.weight, latest.height));
    const weeklyExercise = state.history.slice(-7).reduce((acc, curr) => acc + curr.exercise, 0);
    
    let score = 90;
    let risk = "低風險";
    let riskDesc = "您的各項指標皆在正常範圍內，請繼續保持良好的生活習慣。";
    let diet = "建議攝取更多深色蔬菜與優質蛋白質，減少飽和脂肪酸的攝取。";
    let exercise = "本週運動量已達標，可嘗試增加中高強度間歇訓練 (HIIT) 提升心肺功能。";
    let medical = "血壓指標穩定，建議每週固定測量一次並上傳平台追蹤。";

    // BMI Rules
    if (bmi < 18.5) {
        score -= 10;
        diet = "您的體重過輕，建議增加優質熱量與蛋白質攝取，並配合重量訓練。";
    } else if (bmi > 24 && bmi <= 27) {
        score -= 5;
        diet = "體重微幅超出標準，建議控制精緻澱粉攝取，增加膳食纖維。";
    } else if (bmi > 27) {
        score -= 20;
        risk = "中風險";
        riskDesc = "您的 BMI 顯示為肥胖狀態，可能增加心血管疾病風險。";
        diet = "強烈建議實施低碳飲食，並嚴格控制每日總熱量攝取。";
    }

    // BP Rules
    if (latest.systolic >= 130 || latest.diastolic >= 80) {
        score -= 15;
        risk = "中風險";
        riskDesc = "您的血壓偏高，請注意飲食中的鈉攝取量，並規律運動。";
        medical = "血壓處於高血壓前期，建議每日早晚固定量測血壓，並諮詢醫師。";
    }

    // HR Rules
    if (latest.hr > 100) {
        score -= 10;
        risk = (risk === "中風險") ? "高風險" : "中風險";
        medical = "靜息心率過高，若伴隨心悸或不適，請務必儘速就醫檢查。";
    }

    // Exercise Rules
    if (weeklyExercise < 150) {
        score -= 10;
        exercise = "本週運動時間不足 150 分鐘，建議每天增加至少 20 分鐘的快走或有氧運動。";
    }

    return { score, risk, riskDesc, diet, exercise, medical };
}

// --- UI Rendering ---
function renderAll() {
    renderDashboard();
    renderFHIR();
    renderTrends();
    renderAI();
    renderBlockchain();
    renderNotifications();
    updateUserDisplay();
}

function updateUserDisplay() {
    const roleMap = {
        'user': { name: state.patient.name, label: 'Patient', color: '0ea5e9' },
        'coach': { name: 'Coach Mike', label: 'Coach', color: '6366f1' },
        'nutritionist': { name: 'Sarah RD', label: 'Nutritionist', color: '10b981' },
        'admin': { name: 'System Admin', label: 'Admin', color: '64748b' }
    };
    
    const currentInfo = roleMap[state.role] || roleMap['user'];
    
    document.getElementById('current-username').textContent = currentInfo.name;
    document.getElementById('current-role-display').textContent = currentInfo.label;
    document.getElementById('role-badge').textContent = currentInfo.label;
    document.getElementById('current-avatar').src = `https://ui-avatars.com/api/?name=${encodeURIComponent(currentInfo.name)}&background=${currentInfo.color}&color=fff`;
}

function renderDashboard() {
    const latest = getLatestData();
    const bmi = calculateBMI(latest.weight, latest.height);
    const weeklyExercise = state.history.slice(-7).reduce((acc, curr) => acc + curr.exercise, 0);

    document.getElementById('kpi-bp').textContent = `${latest.systolic}/${latest.diastolic}`;
    document.getElementById('kpi-hr').textContent = latest.hr;
    document.getElementById('kpi-weight').textContent = latest.weight;
    document.getElementById('kpi-bmi').textContent = bmi;
    document.getElementById('kpi-steps').textContent = latest.steps.toLocaleString();
    document.getElementById('kpi-exercise').textContent = weeklyExercise;

    // Status logic
    const bpStatus = (latest.systolic < 120 && latest.diastolic < 80) ? "正常" : "偏高";
    document.getElementById('status-bp').textContent = bpStatus;
    document.getElementById('status-bp').className = "kpi-status " + (bpStatus === "正常" ? "" : "text-red");

    const hrStatus = (latest.hr >= 60 && latest.hr <= 100) ? "正常" : "偏高";
    document.getElementById('status-hr').textContent = hrStatus;
    document.getElementById('status-hr').className = "kpi-status " + (hrStatus === "正常" ? "" : "text-red");

    let bmiStatus = "正常";
    if (bmi < 18.5) bmiStatus = "體重過輕";
    else if (bmi > 24) bmiStatus = "體重過重";
    document.getElementById('status-bmi').textContent = bmiStatus;

    const analysis = runAIAnalysis();
    document.getElementById('kpi-score').textContent = analysis.score;
    
    const completion = Math.min(100, (weeklyExercise / 150 * 100).toFixed(0));
    document.getElementById('kpi-completion').textContent = completion;
    document.getElementById('progress-completion').style.width = completion + "%";
}

function renderFHIR() {
    const bundle = generateFHIRBundle();
    document.getElementById('fhir-output').textContent = formatJSON(bundle);

    const latest = getLatestData();
    const summaryList = document.getElementById('data-summary-list');
    summaryList.innerHTML = `
        <div class="summary-item"><span>血壓</span><strong>${latest.systolic}/${latest.diastolic} mmHg</strong></div>
        <div class="summary-item"><span>體重</span><strong>${latest.weight} kg</strong></div>
        <div class="summary-item"><span>心率</span><strong>${latest.hr} bpm</strong></div>
        <div class="summary-item"><span>更新時間</span><strong>${latest.date}</strong></div>
    `;
}

function renderAI() {
    const analysis = runAIAnalysis();
    document.getElementById('ai-score-value').textContent = analysis.score;
    document.getElementById('ai-risk-level').textContent = analysis.risk;
    document.getElementById('ai-risk-desc').textContent = analysis.riskDesc;
    document.getElementById('ai-diet-suggest').textContent = analysis.diet;
    document.getElementById('ai-exercise-suggest').textContent = analysis.exercise;
    document.getElementById('ai-medical-suggest').textContent = analysis.medical;

    // Change risk color
    const card = document.getElementById('ai-risk-card');
    if (analysis.risk === "低風險") {
        card.style.background = "linear-gradient(135deg, #0ea5e9 0%, #10b981 100%)";
    } else if (analysis.risk === "中風險") {
        card.style.background = "linear-gradient(135deg, #f59e0b 0%, #ef4444 100%)";
    } else {
        card.style.background = "linear-gradient(135deg, #ef4444 0%, #7f1d1d 100%)";
    }
}

function renderTrends() {
    const labels = state.history.map(h => h.date);
    
    // BP Chart
    updateChart('chart-bp', 'line', labels, [
        { label: '收縮壓', data: state.history.map(h => h.systolic), borderColor: '#ef4444', tension: 0.3 },
        { label: '舒張壓', data: state.history.map(h => h.diastolic), borderColor: '#3b82f6', tension: 0.3 }
    ]);

    // Weight/BMI Chart
    updateChart('chart-weight', 'line', labels, [
        { label: '體重 (kg)', data: state.history.map(h => h.weight), borderColor: '#0ea5e9', tension: 0.3 },
        { label: 'BMI', data: state.history.map(h => calculateBMI(h.weight, h.height)), borderColor: '#10b981', tension: 0.3, yAxisID: 'y1' }
    ], {
        scales: { y1: { type: 'linear', display: true, position: 'right', grid: { drawOnChartArea: false } } }
    });

    // HR Chart
    updateChart('chart-hr', 'line', labels, [
        { label: '心率 (bpm)', data: state.history.map(h => h.hr), borderColor: '#ec4899', backgroundColor: 'rgba(236, 72, 153, 0.1)', fill: true, tension: 0.3 }
    ]);

    // Exercise Chart
    updateChart('chart-exercise', 'bar', labels, [
        { label: '運動時間 (min)', data: state.history.map(h => h.exercise), backgroundColor: '#6366f1' }
    ]);
}

function updateChart(id, type, labels, datasets, options = {}) {
    if (charts[id]) charts[id].destroy();
    const ctx = document.getElementById(id).getContext('2d');
    charts[id] = new Chart(ctx, {
        type: type,
        data: { labels, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'top', labels: { usePointStyle: true, boxWidth: 6 } } },
            ...options
        }
    });
}

function renderBlockchain() {
    const tbody = document.getElementById('blockchain-logs');
    tbody.innerHTML = state.blockchainLogs.map(log => `
        <tr>
            <td><code>${log.hash}</code></td>
            <td>${log.from}</td>
            <td>${log.to}</td>
            <td>${log.data}</td>
            <td>${log.time}</td>
            <td><span class="status-badge status-success">${log.status}</span></td>
        </tr>
    `).join('');
}

function renderNotifications() {
    const container = document.getElementById('notification-timeline');
    container.innerHTML = state.notifications.map(n => `
        <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
                <div class="timeline-time">${n.time}</div>
                <div class="timeline-title">${n.title}</div>
                <div class="timeline-desc text-sm color-muted">${n.desc}</div>
            </div>
        </div>
    `).join('');
}

// --- Interaction Handlers ---

// Navigation
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
        const target = item.getAttribute('data-target');
        document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active'));
        document.getElementById(target).classList.add('active');
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        
        // Refresh charts if needed
        if (target === 'trend-section') renderTrends();
    });
});

// Role Selection
document.querySelectorAll('.btn-select-role').forEach(btn => {
    btn.addEventListener('click', (e) => {
        const role = e.target.closest('.role-card').getAttribute('data-role');
        state.role = role;
        saveState();
        updateUserDisplay();
        
        document.querySelectorAll('.role-card').forEach(c => c.classList.remove('selected'));
        e.target.closest('.role-card').classList.add('selected');

        alert(`已切換為 ${role} 視角`);
        // Navigate to dashboard after login
        document.querySelector('[data-target="dashboard-section"]').click();
    });
});

// Form Submission
document.getElementById('health-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const newData = {
        date: document.getElementById('input-date').value || new Date().toISOString().split('T')[0],
        systolic: parseInt(document.getElementById('input-systolic').value),
        diastolic: parseInt(document.getElementById('input-diastolic').value),
        weight: parseFloat(document.getElementById('input-weight').value),
        height: parseInt(document.getElementById('input-height').value),
        hr: parseInt(document.getElementById('input-hr').value),
        steps: parseInt(document.getElementById('input-steps').value),
        exercise: parseInt(document.getElementById('input-duration').value),
        calories: parseInt(document.getElementById('input-calories').value)
    };

    state.history.push(newData);
    
    // Add notification
    state.notifications.unshift({
        title: "FHIR 資料同步成功",
        desc: "新的量測數據已成功上傳至 HAPI FHIR Server。",
        time: "剛剛",
        type: "sync"
    });

    saveState();
    renderAll();

    // Show toast
    const toast = document.getElementById('success-toast');
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3000);
});

// QR Code Generation
document.getElementById('btn-generate-share').addEventListener('click', () => {
    const target = document.getElementById('share-target').value;
    const qrcodeContainer = document.getElementById('qrcode');
    qrcodeContainer.innerHTML = "";
    new QRCode(qrcodeContainer, {
        text: `FHIR-AUTH-${state.patient.id}-${target}-${Date.now()}`,
        width: 160,
        height: 160
    });

    document.getElementById('qr-hint').classList.add('hidden');
    document.getElementById('qr-info').classList.remove('hidden');
    const hash = "0x" + Math.random().toString(16).substr(2, 32).toUpperCase();
    document.getElementById('temp-auth-hash').textContent = hash.substr(0, 16) + "...";

    // Add to blockchain log
    state.blockchainLogs.unshift({
        hash: hash.substr(0, 10) + "...",
        from: state.patient.name,
        to: document.getElementById('share-target').options[document.getElementById('share-target').selectedIndex].text,
        data: "授權資料",
        time: new Date().toLocaleString(),
        status: "Success"
    });
    saveState();
});

// Reset Data
document.getElementById('btn-reset-data').addEventListener('click', () => {
    if (confirm("確定要重置所有 Demo 資料嗎？")) {
        localStorage.removeItem('health_platform_state');
        state = JSON.parse(JSON.stringify(DEFAULT_DATA));
        renderAll();
        location.reload();
    }
});

// Copy FHIR
document.getElementById('btn-copy-fhir').addEventListener('click', () => {
    const text = document.getElementById('fhir-output').textContent;
    navigator.clipboard.writeText(text).then(() => {
        alert("FHIR JSON 已複製到剪貼簿");
    });
});

// --- Initialize ---
window.onload = () => {
    // Set default date in form
    document.getElementById('input-date').value = new Date().toISOString().split('T')[0];
    renderAll();
};
